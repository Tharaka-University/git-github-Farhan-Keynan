<?php
$vote = $_POST['vote'];

//connect to database
$con = mysqli_connect('localhost:3307', 'username', '', 'tharaka_university');

$sql = "UPDATE candidates SET votes = votes + 1 WHERE id = $vote";
$result = mysqli_query($con, $sql);

$sql = "SELECT * FROM candidates";
$result = mysqli_query($con, $sql);

$candidates = array();

while($row = mysqli_fetch_assoc($result)) {
    $candidates[] = $row;
}

mysqli_close($con);
?>

<html>
<head>
<title>Result Page</title>
</head>
<body>
<?php foreach($candidates as $candidate): ?>
<p>
<?php echo $candidate['name']; ?><br>
<img src="<?php echo $candidate['photo']; ?>"><br>
<?php echo $candidate['votes']; ?> votes
</p>
<?php endforeach; ?>
</body>
</html>