<?php 
session_start();

$registration = $_POST['registration'];
$password = $_POST['password'];

$conn_servername = 'localhost:3307';
$conn_username = 'root';
$conn_password = '';
$conn_database = 'tharaka_university';
$conn = new mysqli($conn_servername,$conn_username,$conn_password,$conn_database);


if($conn -> connect_error) {
	die("Connection failed:" .$conn -> connect_error);
}else{
	$einstein = $conn -> prepare('select * from student where registration = ? AND password = ? ');	
	$einstein -> bind_param("ss", $registration,$password);	
	$einstein -> execute();	
	$einstein_result = $einstein->get_result();

	if($einstein_result->num_rows > 0) {
		$data = $einstein_result->fetch_assoc();
		if($data['registration'] === $registration &&	$data['password'] === $password){
			
			$_SESSION['registration'] = $registration; 
		  
			echo "			
				<img src = 'images/logo.jpg' width='250' height='250' style='margin-center:5px;margin-left:auto;
				margin-right:auto; display:block;'> 
		 
		        <h2 style = 'text-align:center;color:#3e4290;'>STUDENT VOTING ACCOUNT</h2>	  
				<center style ='background-color:rgb(26, 8, 102);border:50px solid white;border-radius:200px;font-weight:bold;font-size:20px;color:#3e4290';margin: -200px;>
			  
	              <p style ='font-size:50px;color:white;'>Success!!</p>
				  
				  <br><br>
				  
				  LOGIN SUCCESSFUL
				  <strong>
					<br><br>Hello and welcome to your student voting account.<br>
					<br><br><br> 
				  </strong>
				  
				  <br><br><br><br><br><br>
				  <a href = 'validate_voters.php'>Click here to vote</a>
				  <br><br><br><br><br>	     
		        </center>";
		}else{
			echo "	     
			<img src = 'images/logo.jpg' width='250' height='250' style='margin-center:5px;margin-left:auto;
			margin-right:auto;display:block;'> 
		 
		    <h2 style = 'text-align:center;color:#3e4290;'>STUDENT VOTING ACCOUNT</h2>	 
			<center style ='background-color:rgb(26, 8, 102);border:50px solid white;border-radius:200px;font-weight:bold;font-size:20px;color:#3e4290';margin: -200px;>
	
				<br><br><br><br><br><br>
				
				<p style ='font-size:50px;color:white;'>FAILED!!</p>
				
				<br><br><br>	  
				  
				 <strong>
					<br><br><br>INVALID REGISTRATION OR PASSWORD
					<br><br><br><i style = 'color:white;'>KINDLY CHECK TO CONFIRM THAT YOU ENTERED THE CORRECT PASSWORD THEN TRY AGAIN!</i>
				 </strong>
				  
				  <br><br><br><br><br><br>
	     
		     </center>"; 
		}
	}else{
	
	    echo "	     
			<img src = 'images/logo.jpg' width='250' height='250' style='margin-center:5px;margin-left:auto;
			margin-right:auto;display:block;'> 
		 
		    <h2 style = 'text-align:center;color:#3e4290;'>STUDENT VOTING ACCOUNT</h2>	 
			<center style ='background-color:rgb(26, 8, 102);border:50px solid white;border-radius:200px;font-weight:bold;font-size:20px;color:#3e4290';margin: -200px;>
	
				<br><br><br><br><br><br>
				
				<p style ='font-size:50px;color:white;'>FAILED!!</p>
				
				<br><br><br>	  
				  
				 <strong>
					<br><br><br>INVALID REGISTRATION OR PASSWORD
					<br><br><br><i style = 'color:white;'>KINDLY CHECK TO CONFIRM THAT YOU ENTERED THE CORRECT PASSWORD THEN TRY AGAIN!</i>
				 </strong>
				  
				  <br><br><br><br><br><br>
	     
		     </center>"; 
	}

	$einstein -> close();
	$conn -> close();

}
?>
	