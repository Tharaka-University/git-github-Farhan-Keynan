<?php 

$voted_candidate = "";

// checks if the form is ready
if(isset($_POST['voted_candidate'])){
    $voted_candidate = $_POST['voted_candidate'];
}

$conn_servername = 'localhost:3307';
$conn_username = 'root';
$conn_password = '';
$conn_database = 'tharaka_university';


$conn = new mysqli($conn_servername,$conn_username,$conn_password,$conn_database);


if($conn -> connect_error) {
	die("Connection failed: " .$conn -> connect_error);
}else{
    $add_vote_stmt =  $conn -> prepare("UPDATE femalehostvotes SET number_of_votes=
                                    (SELECT number_of_votes FROM femalehostvotes WHERE candidate=?)+1 WHERE candidate=?");
	
	$add_vote_stmt -> bind_param("ss",$voted_candidate, $voted_candidate);
	$add_vote_stmt -> execute();

    // show the results now
    $show_results_stmt = $conn -> prepare("select * from femalehostvotes"); 
    $show_results_stmt -> execute();
    $results = $show_results_stmt->get_result();
    if ( $results->num_rows > 0) {
            while($row =  $results->fetch_assoc()) {
                echo "Candidate Name: ".$row["candidate"]. "  - femalehostvotes: " . $row["number_of_votes"]."<br>";
            }
        } else {
        echo "No results";
        }
}
?>