<?php 

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$password = $_POST['password'];
$registration= $_POST['registration'];
$department= $_POST['department'];
$faculty= $_POST['faculty'];


$conn_servername = 'localhost:3307';
$conn_username = 'root';
$conn_password = '';
$conn_database = 'tharaka_university';

$conn = new mysqli($conn_servername,$conn_username,$conn_password,$conn_database);

if($conn -> connect_error) {
	die("Connection failed:" .$conn -> connect_error);
}else{
	$einstein = $conn -> prepare('insert into student(fname, lname,password,registration,department,faculty)
	            values(?,?,?,?,?,?)');
	
	$einstein -> bind_param("ssssss", $fname, $lname,$password,$registration,$department,$faculty);
	$einstein -> execute();
	
	echo "	    
		<img src = 'images/logo.jpg' width='250' height='250' style='margin-center:5px;margin-left:auto;
		margin-right:auto;display:block;'>

		<h1 style = 'text-align:center;color:#3e4290;'>STUDENT  REGISTRATION</h1>		 
		<center style ='background-color:rgb(26, 8, 102);border:50px solid white;border-radius:500px;font-weight:bold;font-size:20px;color:white'>

			<br><br><br><br><br><br>
			
			<p style ='font-size:50px;color:white;'>Success!!</p>
			
			<br><br><br>
			
			Hey $fname, your portal account has been successfully created as $registration
			<br>You can now login to your portal
			
			<br><br><br><br><br><br>
			
			<a href = 'login.html'>Click here to login</a>
			<br><br><br><br><br><br>		
		</center>"; 

	$einstein -> close();
	$conn -> close();
	
}

?>