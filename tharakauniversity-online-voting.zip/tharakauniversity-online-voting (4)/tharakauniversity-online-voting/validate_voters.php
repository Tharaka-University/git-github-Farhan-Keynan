<?php
session_start();

$registration = $_SESSION['registration'];


$conn_servername = 'localhost:3307';
$conn_username = 'root';
$conn_password = '';
$conn_database = 'tharaka_university';
$conn = new mysqli($conn_servername,$conn_username,$conn_password,$conn_database);


$validate_voter_stmt = $conn -> prepare('select voted from student where registration = ?');	
$validate_voter_stmt -> bind_param("s", $registration);	
$validate_voter_stmt -> execute();	
$result = $validate_voter_stmt->get_result();

if($conn -> connect_error) {
	die("Connection failed:" .$conn -> connect_error);
}else{

    if($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        if($data['voted'] == 1){
            echo "<h2 style = 'text-align:center;color:#3e4290;'>you already voted</h2>";
        }else{
            header("location:voting.html");
        }
    }
}
?>